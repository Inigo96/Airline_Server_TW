package es.deusto.ingenieria.sd.jdo.inventory;


import javax.jdo.annotations.PersistenceCapable;

@PersistenceCapable
public class Passenger {
	private int id;
    private String DNI = null;
    private String name = null;
	
    public Passenger(int id, String dNI, String name) {
		this.id = id;
		DNI = dNI;
		this.name = name;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getDNI() {
		return DNI;
	}

	public void setDNI(String dNI) {
		DNI = dNI;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
    

    
}
