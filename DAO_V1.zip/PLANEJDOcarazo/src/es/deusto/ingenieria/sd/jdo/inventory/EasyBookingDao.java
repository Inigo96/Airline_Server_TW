package es.deusto.ingenieria.sd.jdo.inventory;

import java.util.List;

import javax.jdo.Extent;



public interface EasyBookingDao {
	//Show all instances of the object
	public Extent<Passenger> getAllPassengers();
    public Extent<User> getAllUsers();
    public Extent<Reservation> getAllReservations();
    public Extent<Flight> getAllFlights();
    
    //Show only one instance
    public Passenger loadPassenger(int id);
    public User loadUser(int id);
    public Reservation loadReservation(int id);
    public Flight loadFlight(int id);
    
    //Store one instance on the DB
    public Passenger storePassenger(Passenger p);
    public User storeUser(User u);
    public Reservation storeReservation(Reservation r);
    public Flight storeFlight(Flight f);
	
	
	
}
