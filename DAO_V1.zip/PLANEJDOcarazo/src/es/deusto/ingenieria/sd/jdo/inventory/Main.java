package es.deusto.ingenieria.sd.jdo.inventory;

import java.sql.Date;

import javax.jdo.Extent;
import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Transaction;


public class Main {
	 @SuppressWarnings("deprecation")
    public static void main(String[] args) {

//CREATE DATABASE
        try {
            PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
            PersistenceManager pm = pmf.getPersistenceManager();

            Transaction tx = pm.currentTransaction();

            try {
                tx.begin();
                Passenger p1=new Passenger(0,"32","aa");
                Passenger p2=new Passenger(1,"33","bb");
                Passenger p3=new Passenger(2,"34","cc");
                Passenger p4=new Passenger(3,"35","dd");
                Passenger p5=new Passenger(4,"36","ee");
                Passenger p6=new Passenger(5,"37","ff");
                Passenger p7=new Passenger(6,"38","gg");
                Passenger p8=new Passenger(7,"39","hh");
                Passenger p9=new Passenger(8,"40","ii");

               
				Flight f1 =new Flight (0,"Bilbao","Madrid",new Date(29,12,2016));
                Flight f2 =new Flight (1,"Bilbao","Barcelona",new Date(29,12,2016));
                
                Flight f3 =new Flight (2,"Barcelona","Bilbao",new Date(30,12,2016));
                Flight f4 =new Flight (3,"Barcelona","Madrid",new Date(30,12,2016));
                
                Flight f5 =new Flight (4,"Madrid","Barcelona",new Date(31,12,2016));
                Flight f6 =new Flight (5,"Bilbao","Valencia",new Date(31,12,2016));
                
                Flight f7 =new Flight (6,"Valencia","Madrid",new Date(1,1,2016));
                Flight f8 =new Flight (7,"Valencia","Bilbao",new Date(1,1,2016));
                
                
                Reservation r1=new Reservation("0");
                Reservation r2=new Reservation("1");
                Reservation r3=new Reservation("2");
                Reservation r4=new Reservation("3");

                User u1=new User(0,"user1","pass1");
                User u2=new User(1,"user2","pass2");
                User u3=new User(2,"user3","pass3");
 
          //Reservation 1  flights       
                
                r1.addPass(p1);
                r1.addPass(p2);
                r1.addFlight(f1);
                
                
         //Reservation 2  flights          
                
                
                r2.addPass(p3);
                r2.addPass(p4);
                r2.addFlight(f2);
                
        //Reservation 3 flights       
                
                r3.addPass(p5);
                r3.addPass(p6);
                r3.addFlight(f3);
                
                
         //Reservation 4 flights          
                
                
                r4.addPass(p7);
                r4.addPass(p8);
                r4.addFlight(f4);
                
                
            //User 1 reservations              
                u1.addReservation(r1);
                u1.addReservation(r2);
                pm.makePersistent(u1);
                
            //User 2 reservations 
                u2.addReservation(r3);
                u2.addReservation(r4);
                pm.makePersistent(u2);
                
                
                
                System.out.println("Inserting contents into the database ....");
                tx.commit();
            } catch (Exception ex) {
                System.out.println("# Error storing objects: " + ex.getMessage());
            } finally {
                if (tx.isActive()) {
                    tx.rollback();
                }
                pm.close();
            }

            pm = pmf.getPersistenceManager();
            tx = pm.currentTransaction();
            /**
           //Modify DATABASE
            try {

                tx.begin();

                Extent<Reservation> extentP = pm.getExtent(Reservation.class);
                int cont = 0;
                for (Reservation p : extentP) {
                    System.out.println((cont++) + " - " + p.getID() + " - " + p.getPrice());
                }
                System.out.println(" DB is modified");


                for (Reservation p : extentP) {
                    p.setPrice(1000000000);
                    System.out.println((cont++) + " - " + p.getID() + " - " + p.getPrice());
                }

                tx.commit();
            } catch (Exception ex) {
                System.out.println("# Error getting Extent: " + ex.getMessage());
            } finally {
                if (tx.isActive()) {
                    tx.rollback();
                }

                pm.close();
            }

            pm = pmf.getPersistenceManager();
            tx = pm.currentTransaction();

            pm = pmf.getPersistenceManager();
            tx = pm.currentTransaction();

            try {
                tx.begin();

                Extent<User> extentP = pm.getExtent(User.class);

                for (User product : extentP) {
                    pm.deletePersistent(product);
                }

                System.out.println("Deleting user");
                tx.commit();
            } catch (Exception ex) {
                System.out.println("# Error cleaning DB: " + ex.getMessage());
                ex.printStackTrace();
            } finally {
                if (tx.isActive()) {
                    tx.rollback();
                }

                pm.close();
            }

            */
        } catch (Exception ex) {
            ex.printStackTrace(System.err);
        }



    }
    
}
