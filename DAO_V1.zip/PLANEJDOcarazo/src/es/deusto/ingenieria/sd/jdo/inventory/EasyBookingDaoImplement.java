package es.deusto.ingenieria.sd.jdo.inventory;

import javax.jdo.*;
import java.util.List;


public class EasyBookingDaoImplement implements EasyBookingDao{
PersistenceManagerFactory pmf;
    
    /** Constructor, defining the PersistenceManagerFactory to use. */
    public EasyBookingDaoImplement(PersistenceManagerFactory pmf)
    {
        this.pmf = pmf;
    }
    
    /** Accessor for a PersistenceManager */
    protected PersistenceManager getPersistenceManager()
    {
        return pmf.getPersistenceManager();
    }
    
    public Extent<Passenger> getAllPassengers()
    {
    	
    	
    	PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx = pm.currentTransaction();
        Extent<Passenger> extentP;
        try
        {
            tx.begin();

            extentP = pm.getExtent(Passenger.class);
            int cont = 0;
            for (Passenger p : extentP) {
            	System.out.println((cont++) + " - " + p.getId()+ " - " + p.getDNI() + " - " + p.getName());
            }
           

            tx.commit();
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
        return extentP;
    }
    
    public Extent<User> getAllUsers()
    {
    	
    	
    	PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx = pm.currentTransaction();
        Extent<User> extentU;
        try
        {
            tx.begin();

            extentU = pm.getExtent(User.class);
            int cont = 0;
            for (User u : extentU) {
            	System.out.println((cont++) + " - " + u.getId()+ " - " + u.getUsername() + " - " + u.getPassword());
            }
           

            tx.commit();
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
        return extentU;
    }
    
    public Extent<Reservation> getAllReservations()
    {
    	
    	
    	PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx = pm.currentTransaction();
        Extent<Reservation> extentR;
        try
        {
            tx.begin();

            extentR = pm.getExtent(Reservation.class);
            int cont = 0;
            for (Reservation r : extentR) {
            	System.out.println((cont++) + " - " +r.getId());
            	
            }
           

            tx.commit();
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
        return extentR;
    }
    
    public Extent<Flight> getAllFlights()
    {
    	
    	
    	PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx = pm.currentTransaction();
        Extent<Flight> extentF;
        try
        {
            tx.begin();

            extentF = pm.getExtent(Flight.class);
            int cont = 0;
            for (Flight f : extentF) {
            	System.out.println((cont++) + " - " + f.getId()+ " - " + f.getArrivalA() + " - " + f.getDepartureA()+ " - " + f.getDate());
            }
           

            tx.commit();
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
        return extentF;
    }
    
    
    
    
    
    
    
    
    
    
    
    
    
    
}
