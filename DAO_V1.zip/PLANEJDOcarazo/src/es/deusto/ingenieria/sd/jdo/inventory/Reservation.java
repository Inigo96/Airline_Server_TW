package es.deusto.ingenieria.sd.jdo.inventory;

import java.util.ArrayList;
import java.util.List;
import javax.jdo.annotations.*;

@PersistenceCapable
public class Reservation {
    private String id="";
	@Join
    private List<Flight> flightList=new ArrayList<>();
	@Join
	private List<Passenger> passList=new ArrayList<>();
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	void addPass(Passenger p){
        passList.add(p);
    }

    void getPass(int a){
        passList.get(a);
    }
    
    void addFlight(Flight f){
    	flightList.add(f);
    }

    void getFlight(int b){
    	flightList.get(b);
    }
	
	
	
	public Reservation(String id) {
		this.id = id;
	}
	


}
