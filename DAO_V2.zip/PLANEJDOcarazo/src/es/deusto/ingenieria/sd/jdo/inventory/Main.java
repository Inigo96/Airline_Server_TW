package es.deusto.ingenieria.sd.jdo.inventory;

import java.sql.Date;

import javax.jdo.Extent;
import javax.jdo.JDOHelper;
import javax.jdo.PersistenceManager;
import javax.jdo.PersistenceManagerFactory;
import javax.jdo.Transaction;


public class Main {
	 @SuppressWarnings("deprecation")
    public static void main(String[] args) {
		 EasyBookingDao easyBookingDao=new EasyBookingDaoImplement(null);
//CREATE DATABASE
               
				Flight f1 =new Flight (0,"Bilbao","Madrid",new Date(29,12,2016));
                Flight f2 =new Flight (1,"Bilbao","Barcelona",new Date(29,12,2016));
                
                Flight f3 =new Flight (2,"Barcelona","Bilbao",new Date(30,12,2016));
                Flight f4 =new Flight (3,"Barcelona","Madrid",new Date(30,12,2016));
                
                
                
                
                Reservation r1=new Reservation("0");
                Reservation r2=new Reservation("1");
                Reservation r3=new Reservation("2");
                Reservation r4=new Reservation("3");

                User u1=new User(0,"user1","pass1");
                User u2=new User(1,"user2","pass2");
                User u3=new User(2,"user3","pass3");
 
          //Reservation 1  flights       
                easyBookingDao.storeReservation(r1);    
                easyBookingDao.storeFlight(f1);
                               
          //Reservation 2  flights          
                easyBookingDao.storeReservation(r2);    
                easyBookingDao.storeFlight(f2);
                
        //Reservation 3 flights       
                easyBookingDao.storeReservation(r3);    
                easyBookingDao.storeFlight(f3);
                               
         //Reservation 4 flights          
                easyBookingDao.storeReservation(r4);    
                easyBookingDao.storeFlight(f4);
                
                
            //User 1 reservations              
                
             
                
            //User 2 reservations 
                u2.addReservation(r3);
                u2.addReservation(r4);


  
	 }
}
