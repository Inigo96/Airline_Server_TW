package es.deusto.ingenieria.sd.jdo.inventory;

import javax.jdo.*;
import java.util.List;


public class EasyBookingDaoImplement implements EasyBookingDao{
PersistenceManagerFactory pmf;
    
    /** Constructor, defining the PersistenceManagerFactory to use. */
    public EasyBookingDaoImplement(PersistenceManagerFactory pmf)
    {
        this.pmf = pmf;
    }
    
    /** Accessor for a PersistenceManager */
    protected PersistenceManager getPersistenceManager()
    {
        return pmf.getPersistenceManager();
    }
    
   
    
    public Extent<User> getAllUsers()
    {
    	
    	
    	PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx = pm.currentTransaction();
        Extent<User> extentU;
        try
        {
            tx.begin();

            extentU = pm.getExtent(User.class);
            int cont = 0;
            for (User u : extentU) {
            	System.out.println((cont++) + " - " + u.getId()+ " - " + u.getUsername() + " - " + u.getPassword());
            }
           

            tx.commit();
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
        return extentU;
    }
    
    public Extent<Reservation> getAllReservations()
    {
    	
    	
    	PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx = pm.currentTransaction();
        Extent<Reservation> extentR;
        try
        {
            tx.begin();

            extentR = pm.getExtent(Reservation.class);
            int cont = 0;
            for (Reservation r : extentR) {
            	System.out.println((cont++) + " - " +r.getId());
            	
            }
           

            tx.commit();
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
        return extentR;
    }
    
    public Extent<Flight> getAllFlights()
    {
    	
    	
    	PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
        PersistenceManager pm = pmf.getPersistenceManager();
        Transaction tx = pm.currentTransaction();
        Extent<Flight> extentF;
        try
        {
            tx.begin();

            extentF = pm.getExtent(Flight.class);
            int cont = 0;
            for (Flight f : extentF) {
            	System.out.println((cont++) + " - " + f.getId()+ " - " + f.getArrivalA() + " - " + f.getDepartureA()+ " - " + f.getDate());
            }  

            tx.commit();
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
        return extentF;
    }
    
    
  
    
    public  List<User> loadUser(int id){
    	PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
        PersistenceManager pm = pmf.getPersistenceManager();
 
    	Query q = pm.newQuery(User.class);
    	q.setFilter("id == idParam");
    	q.setOrdering("height desc");
    	q.declareParameters("String idParam");
    	List<User> results;
    	
    	try {
    	  results = (List<User>) q.execute(id);
    	  if (!results.isEmpty()) {
    	    for ( User u: results) {
    	    	
    	    }
    	  } else {
    	    // Handle "no results" case
    	  }
    	} finally {
    	  q.closeAll();
    	}
    	return results;
    	
    	
    	
    	
    }
    
    public  List<Reservation> loadReservation(int id){
    	PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
        PersistenceManager pm = pmf.getPersistenceManager();
    	Query q = pm.newQuery(Reservation.class);
    	q.setFilter("id == idParam");
    	q.setOrdering("height desc");
    	q.declareParameters("String idParam");
    	List<Reservation> results;
    	try {
    	  results = (List<Reservation>) q.execute(id);
    	  if (!results.isEmpty()) {
    	    for (Reservation r : results) {
    	      
    	    	
    	    }
    	  } else {
    	    
    	  }
    	} finally {
    	
    	  q.closeAll();
    	}
    	return results;
    }
    
    public  List<Flight> loadFlight(int id){
    	PersistenceManagerFactory pmf = JDOHelper.getPersistenceManagerFactory("datanucleus.properties");
        PersistenceManager pm = pmf.getPersistenceManager();
    	Query q = pm.newQuery(Flight.class);
    	q.setFilter("id == idParam");
    	q.setOrdering("height desc");
    	q.declareParameters("String idParam");
    	List<Flight> results;
    	try {
    	   results= (List<Flight>) q.execute(id);
    	  if (!results.isEmpty()) {
    	    for (Flight f : results) {
    	      // Process result f
    	    }
    	  } else {
    	    // Handle "no results" case
    	  }
    	} finally {
    	  q.closeAll();
    	}
    	return results;
    }
    
    
 
    
    public void storeUser(User u){
    	
    	PersistenceManager pm = getPersistenceManager();
        Transaction tx = pm.currentTransaction();
        try
        {
            tx.begin();

            // Persist our changes back to the datastore
            pm.makePersistent(u);

            tx.commit();
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
    }
    
    
    public void storeReservation(Reservation r){
    	PersistenceManager pm = getPersistenceManager();
        Transaction tx = pm.currentTransaction();
        try
        {
            tx.begin();

            // Persist our changes back to the datastore
            pm.makePersistent(r);

            tx.commit();
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
    }
    
    
    public void storeFlight(Flight f){
    	PersistenceManager pm = getPersistenceManager();
        Transaction tx = pm.currentTransaction();
        try
        {
            tx.begin();

            // Persist our changes back to the datastore
            pm.makePersistent(f);

            tx.commit();
        }
        finally
        {
            if (tx.isActive())
            {
                tx.rollback();
            }
            pm.close();
        }
    }
    
    
    
    
    
    
    
    
    
    
    
    
}
