package es.deusto.ingenieria.sd.jdo.inventory;

public class DaoDemo {

}
