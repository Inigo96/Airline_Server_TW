package es.deusto.ingenieria.sd.jdo.inventory;

import java.util.List;

import javax.jdo.Extent;



public interface EasyBookingDao {
	//Show all instances of the object
	
    public Extent<User> getAllUsers();
    public Extent<Reservation> getAllReservations();
    public Extent<Flight> getAllFlights();
    
    //Show only one instance
   
    public List<User> loadUser(int id);
    public List<Reservation> loadReservation(int id);
    public List<Flight> loadFlight(int id);
    
    //Store one instance on the DB
   
    public void storeUser(User u);
    public void storeReservation(Reservation r);
    public void storeFlight(Flight f);
	
	
	
}
