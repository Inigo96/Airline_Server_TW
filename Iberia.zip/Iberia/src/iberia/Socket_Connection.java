package iberia;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketTimeoutException;

/**
 * Created by inigo on 14/01/17.
 */
public class Socket_Connection extends Thread{

    private ServerSocket serverSocket;
    private FlightService flightServer;

    public Socket_Connection(String IP, int port) throws IOException {
        serverSocket = new ServerSocket(port);
        flightServer = new FlightService();
//        serverSocket.setSoTimeout(10000);
    }

    public void run() {
        while(true) {
            try {
                //HAY QUE PONER QUE METEMOS EN ESTE STRING
                String vuelos;
                System.out.println("Waiting for client on port " +
                        serverSocket.getLocalPort() + "...");
                Socket server = serverSocket.accept();

                System.out.println("Just connected to " + server.getRemoteSocketAddress());
                DataInputStream in = new DataInputStream(server.getInputStream());

                System.out.println(in.readUTF());
                DataOutputStream out = new DataOutputStream(server.getOutputStream());
                String[] ask = in.readUTF().split("$$$$$$$$$#");
                System.out.println("ask = " + ask);
                out.writeUTF(this.flightServer.flightsToString(this.flightServer.searchFlight(ask[0],ask[1],ask[2])));
                System.out.println(this.flightServer.flightsToString(this.flightServer.searchFlight(ask[0],ask[1],ask[2])));
                server.close();

            }catch(SocketTimeoutException s) {
                System.out.println("Socket timed out!");
//                break;

            }catch(IOException e) {
                e.printStackTrace();
//                break;
            }
        }
    }
}
