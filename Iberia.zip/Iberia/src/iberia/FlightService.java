package iberia;

/**
 * Created by inigo on 14/01/17.
 */
public class FlightService {
    public Flight[] searchFlight(String departureA, String arrivalA, String date){
        Flight[] ar=new Flight[1];
        ar[0]=new Flight(departureA, arrivalA, date);
        System.out.println("ar[0] = " + ar[0]);
        return ar;
    }

    public String flightsToString(Flight[] f){
        String str="";
        for (Flight flight: f){
            str+=flight.toString()+"$$$$$$$$$#";
        }
        System.out.println("str = " + str);
        return str.substring(0,str.length()-10);
    }
}
