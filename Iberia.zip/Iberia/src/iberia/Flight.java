package iberia;

import java.util.Date;
import java.util.GregorianCalendar;




public class Flight {

    private	String departureA=null;
    private String arrivalA=null;
    private GregorianCalendar date;



    public Flight(String departureA, String arrivalA, String date) {

        this.departureA = departureA;
        this.arrivalA = arrivalA;
        GregorianCalendar r = new GregorianCalendar();
        Date e = new Date();
        e.setTime(Long.valueOf(date).longValue());
        r.setTime(e);
        this.date = r;
    }


    @Override
    public String toString(){
        return departureA + "%&&&%" + arrivalA + "%&&&%" + date.toString();
    }

    public String getDepartureA() {
        return departureA;
    }

    public void setDepartureA(String departureA) {
        this.departureA = departureA;
    }

    public String getArrivalA() {
        return arrivalA;
    }

    public void setArrivalA(String arrivalA) {
        this.arrivalA = arrivalA;
    }

    public GregorianCalendar getDate() {
        return date;
    }

    public void setDate(GregorianCalendar date) {
        this.date = date;
    }


}



