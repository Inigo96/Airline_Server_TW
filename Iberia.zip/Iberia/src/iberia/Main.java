package iberia;

import java.io.IOException;

/**
 * Created by inigo on 14/01/17.
 */

public class Main {
    public static void main(String[] args) throws IOException {
//        String v ="fjfkjf12&&&&&||&&&&&";
//        System.out.println(v.substring(0,v.length()-12));
//        GregorianCalendar r = new GregorianCalendar();
//        r.set(2017,5,24,5,4,3);
//        System.out.println(r.getTimeInMillis());
//        Date e = new Date();
//        e.setTime(r.getTimeInMillis());
//        r.setTime(e);
////        r.setGregorianChange(new Date().setTime(r.getTimeInMillis()));
//        System.out.println(r.getTimeInMillis());
        if (args.length < 1) {
            System.err.println(" # Usage: TCPSocketSever [PORT]");
            System.exit(1);
        }
        int serverPort = Integer.parseInt(args[1]);
        String serverIP = args[0];

        Socket_Connection conn= new Socket_Connection(serverIP, serverPort);
        conn.run();
    }
}
