package airFrance;


import java.rmi.RemoteException;

/**
 * Created by inigo on 15/01/17.
 */
public class AirFrance_service  {
    public AirFrance_Flight[] searchFlight(FlightsQuery fq) throws RemoteException {
        AirFrance_Flight[] dev = new AirFrance_Flight[1];
        dev[0]=new AirFrance_Flight(fq.getDeparture(),fq.getArrival(),fq.getDate());
        return dev;
    }
}
