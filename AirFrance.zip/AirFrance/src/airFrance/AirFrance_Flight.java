package airFrance;

import java.io.Serializable;
import java.util.GregorianCalendar;



public class AirFrance_Flight implements Serializable{

	private static final long serialVersionUID = 1L;
	private	String departureA;
	private String arrivalA;
	private GregorianCalendar date;
	
	
	
	public AirFrance_Flight(String departureA, String arrivalA, GregorianCalendar date) {
		super();
		this.departureA = departureA;
		this.arrivalA = arrivalA;
		this.date = date;
	}
	

	public String toString2(){
		return departureA + "%&&&%" + arrivalA + "%&&&%" + date.toString();
	  }

	public String getDepartureA() {
		return departureA;
	}

	public void setDepartureA(String departureA) {
		this.departureA = departureA;
	}

	public String getArrivalA() {
		return arrivalA;
	}

	public void setArrivalA(String arrivalA) {
		this.arrivalA = arrivalA;
	}

	public GregorianCalendar getDate() {
		return date;
	}

	public void setDate(GregorianCalendar date) {
		this.date = date;
	}
	

}


