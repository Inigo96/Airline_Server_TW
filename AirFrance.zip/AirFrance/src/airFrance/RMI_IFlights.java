package airFrance;

import java.rmi.Remote;
import java.rmi.RemoteException;

/**
 * Created by inigo on 15/01/17.
 */
public interface RMI_IFlights extends Remote{
    AirFrance_Flight[] searchFlightRMI(FlightsQuery fq) throws RemoteException;
}
