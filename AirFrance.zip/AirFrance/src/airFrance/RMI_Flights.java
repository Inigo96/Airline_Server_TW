package airFrance;

import java.io.Serializable;
import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;

/**
 * Created by inigo on 15/01/17.
 */
public class RMI_Flights extends UnicastRemoteObject implements RMI_IFlights{
    AirFrance_service airFrance_service;

    public RMI_Flights() throws RemoteException {
        super();
        this.airFrance_service=new AirFrance_service();
    }

    @Override
    public AirFrance_Flight[] searchFlightRMI(FlightsQuery fq) throws RemoteException {
        return this.airFrance_service.searchFlight(fq);
    }

    public static void main(String[] args) {
        if (args.length != 3) {
            System.out.println("usage: java [policy] [codebase] server.Server [host] [port] [server]");
            System.exit(0);
        }

        if (System.getSecurityManager() == null) {
            System.setSecurityManager(new SecurityManager());
        }

        String name = "//" + args[0] + ":" + args[1] + "/" + args[2];

        try {
            RMI_IFlights objServer = new RMI_Flights();
//			objServer.registerUser("client","pass");
            Naming.rebind(name, objServer);
            System.out.println("* Server '" + name + "' active and waiting...");
        } catch (Exception e) {
            System.err.println("- Exception running the server: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
